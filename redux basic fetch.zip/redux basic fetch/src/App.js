// import UserRoutes from "./UserRoutes";

import { Routes, Route } from 'react-router-dom';

import Header from "./modules/Header";
import HomePage from './pages/HomePage/HomePage';
import AddForm from './modules/AddForm/AddForm';
import ProductsPage from "./pages/ProductsPage/ProductsPage";
import CartPage from "./pages/CartPage/CartPage";

import './App.css';

function App() {
  return (
    <div className="App">
      <Header />
      <Routes>
        <Route path='/' element={<HomePage />} />
        <Route path='/add-product' element={<AddForm />}/>
        <Route path="/products" element={<ProductsPage />} />
        <Route path="/cart" element={<CartPage />}/>
      </Routes>
      {/* <UserRoutes /> */}
    </div>
  );
}

export default App;
