import { useState } from 'react';
import {initialState} from './initialState';

function AddForm({onSubmit}) {
    const [form, setForm] = useState({...initialState});

    const handleChange = ({target}) => {
        const {name, value, type, checked} = target;
        const newValue = type === "checkbox" ? checked : value;
        setForm({
            ...form,
            [name]: newValue
        })
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        onSubmit({...form});
        setForm({...initialState})
    }

    const { name, price, description, image } = form;
  return (
    <>
      <h3 className="title-form">Add new product</h3>
      <div className="box-form">
        <form className="form" onSubmit={handleSubmit}>
          <input onChange={handleChange} name='name' type="text" value={name} placeholder="product name" required></input>

          <input onChange={handleChange} name='price' type="number" value={price} placeholder="product price" required></input>

          <input onChange={handleChange} name='description' type="text" value={description} placeholder="product description" required></input>

          <input onChange={handleChange} name='image' type="text" value={image} placeholder="product image url" required></input>

          <button type="submit">Add product</button>
        </form>
      </div>
    </>
  );
}
export default AddForm;
