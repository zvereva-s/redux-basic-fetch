export const initialState = {
    name: '',
    price: '',
    description: '',
    image: '',
};