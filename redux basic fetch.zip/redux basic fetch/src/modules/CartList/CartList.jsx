import { useDispatch, useSelector } from 'react-redux';
import { getProductSelector } from '../../redux/cartProducts/cart-products-selectors';
import cartActions from '../../redux/cartProducts/cart-products-actions';


function CartList() { 
 
    const dispatch = useDispatch();
    
    function onRemoveProduct(id) {
        dispatch(cartActions.removeProduct(id))
    };

    function onIncrementQuantity(id) {
        dispatch(cartActions.incrementQuantity(id))
    }
    function onDecrementQuantity(id) {
        dispatch(cartActions.decrementQuantity(id))
    }

    const products = useSelector(getProductSelector);

    const elements = products.map(({ id, name, price, quantity }) =>
        <li key={id}>
            <p>{name}</p>
            <p>Price:  {price}</p>
            <p>Quantity: {quantity}</p>
            <button onClick={() => onRemoveProduct(id)} type="button">remove</button>
            <button onClick={()=>onIncrementQuantity(id)} type="button">+</button>
            <button onClick={()=>onDecrementQuantity(id)} type="button">-</button>
        </li>)
    
    return (
        <ul>
            {elements}
        </ul>
    )
}
export default CartList;