import { useSelector } from 'react-redux';
import { NavLink, Link } from 'react-router-dom';

import { totalProducts, totalSum } from '../../redux/cartProducts/cart-products-selectors';
import styles from './header.module.css';

function Header() {
    const quantityProducts = useSelector(totalProducts);
    const sumOfProducts = useSelector(totalSum).toFixed(2);

    function getLinkActive({ isActive }) {
    return isActive ? styles.isActive : styles.link
}
    return (
        <header className={styles.header}>
            <div className="container">
                <nav className={styles.wrapper}>
                    <ul className={styles.list}>
                        <li className={styles.logo}><Link className={styles.link} to="/">Logo</Link></li>
                        <li className={styles.navmenu}><NavLink className={getLinkActive} to="/add-product"><p>Add product</p></NavLink></li>
                        <li className={styles.navmenu}><NavLink className={getLinkActive} to="/products" ><p>Products</p></NavLink></li>
                        <li className={styles.navmenu}><NavLink className={getLinkActive} to="/cart"><p>Cart</p></NavLink></li>
                        <li className={styles.navmenu}><p>Total products: <span className={styles.span}>{quantityProducts}</span></p></li>
                        <li className={styles.navmenu}><p>Total sum: <span className={styles.span}>{sumOfProducts } $</span></p></li>
                    </ul>
                </nav>
            </div>
        </header>
    )
 }
export default Header;