import { useEffect } from 'react';
import { useDispatch, useSelector} from 'react-redux';
import cartActions from '../../redux/cartProducts/cart-products-actions';
import { fetchProducts } from '../../redux/products/products-operations';
import { getProducts, getError, getLoading } from '../../redux/products/products-selector';

import styles from './productsList.module.css';

function ProductsList() {
    const products = useSelector(getProducts);
    const loading = useSelector(getLoading);
    const error = useSelector(getError);


    const dispatch = useDispatch();
    
    useEffect(() => {
        dispatch(fetchProducts())
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    function onAddProduct(el) {
        dispatch(cartActions.addProduct(el));
     }
    
    const elements = products.map(({ id, name, price, description, image }) => {

        return <li className={styles.item} key={id}>
            <h3>{name}</h3>
            <p>Price: {price}</p>
            
            <div>
                <img src={image} alt={name} width="100"/>
                <p>Description : {description}</p>
            </div>

        <button className={styles.button} type='button' onClick={()=>onAddProduct({id, price, name})}>Add to cart</button>
        </li>})

    
    
    return (
        <>
            {loading && <p>Loading ...</p>}
            {error && <p>{error.message}</p>}
            <ul className={styles.list}>
            {elements}
            </ul>
        </>
    )
}
export default ProductsList;