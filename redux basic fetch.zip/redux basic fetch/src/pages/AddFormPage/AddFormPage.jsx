import { useDispatch } from "react-redux";
import AddForm from "../../modules/AddForm/AddForm";
import {addProduct} from '../../redux/products/products-operations';

function AddFormPage() {
    const dispatch = useDispatch();

    function onAddProduct(product) {
        dispatch(addProduct(product));
    }

    return (
        <main>
            <div className="container">
                <AddForm onSubmit={onAddProduct}/>
            </div>
        </main>
    )
 };
export default AddFormPage;