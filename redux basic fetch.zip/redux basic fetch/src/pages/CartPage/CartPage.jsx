import CartList from "../../modules/CartList/CartList";

function CartPage() {
    return (
        <main>
            <div className="container">
               <CartList />
            </div>
        </main>
    )
 }
export default CartPage;