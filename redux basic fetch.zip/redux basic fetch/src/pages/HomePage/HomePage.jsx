function HomePage() { 
    return (
        <main>
            <div className="container">
                <h1>LOREM</h1>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Cum blanditiis facere odit asperiores libero, eos at ad excepturi error alias, saepe dolores. Placeat ratione distinctio quasi voluptatibus quod veritatis quos!

                Lorem ipsum dolor, sit amet consectetur adipisicing elit. Facilis ipsa natus officia, eveniet omnis delectus fuga vitae velit cupiditate quia? Quam autem rerum ipsum architecto optio voluptatum fuga veritatis omnis! 
                </p>
            </div>
        </main>
    )
}
export default HomePage;