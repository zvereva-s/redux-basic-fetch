import ProductsList from "../../modules/ProductsList";

function ProductsPage() {
    return (
        <main>
            <div className="container">
                <ProductsList />
            </div>
        </main>
    )
 }
export default ProductsPage;