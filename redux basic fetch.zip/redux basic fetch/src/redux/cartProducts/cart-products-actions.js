import * as types from './cart-products-types';

function addProduct(payload) {
    return {
        type: types.ADD_PRODUCT,
        payload,
    }
}
function removeProduct(payload) {
    return {
        type: types.REMOVE_PRODUCT,
        payload,
    }
}
function incrementQuantity(payload) {
    return {
        type: types.INCREMENT_PRODUCT_QUANTITY,
        payload
    }
}
function decrementQuantity(payload) {
    return {
        type: types.DECREMENT_PRODUCT_QUANTITY,
        payload,
    }
}

const cartActions = {
    addProduct,
    removeProduct,
    incrementQuantity,
    decrementQuantity,
}

export default cartActions;