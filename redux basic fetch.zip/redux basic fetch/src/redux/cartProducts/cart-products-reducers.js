import * as types from './cart-products-types';

const initialStore = [];

const cartReducer = (cartStore = initialStore, {type, payload}) => {
    switch(type) {
        case types.ADD_PRODUCT:

            const isProductInCart = cartStore.find(el => el.id === payload.id);
            if (isProductInCart) {
                const newQuantity = isProductInCart.quantity + 1;
                isProductInCart.quantity = newQuantity;
            }
            else {
                return [...cartStore, { ...payload, quantity: 1 }];
            }
            break;
        case types.INCREMENT_PRODUCT_QUANTITY:
            const product = cartStore.find(el => el.id === payload);
            product.quantity += 1;
            break;
        case types.DECREMENT_PRODUCT_QUANTITY:
            const productDec = cartStore.find(el => el.id === payload);
            productDec.quantity -= 1;
            break;
        case types.REMOVE_PRODUCT:
            return cartStore.filter(item => item.id !== payload);
        
        default: 
            return cartStore;
    }
}

export default cartReducer;