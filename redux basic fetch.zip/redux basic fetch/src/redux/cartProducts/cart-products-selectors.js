export const getProductSelector = store => store.cartProducts;
export const totalProducts = ({ cartProducts }) => cartProducts.reduce((acc, el) => acc + el.quantity, 0);
export const totalSum = ({ cartProducts }) => cartProducts.reduce((acc, el) => acc + el.price * el.quantity, 0);