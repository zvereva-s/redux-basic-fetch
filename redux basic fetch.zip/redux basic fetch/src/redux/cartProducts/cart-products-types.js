export const ADD_PRODUCT = 'add/product';
export const REMOVE_PRODUCT = 'remove/product';
export const INCREMENT_PRODUCT_QUANTITY = 'increment/product-quantity';
export const DECREMENT_PRODUCT_QUANTITY = 'decrement/product-quantity';