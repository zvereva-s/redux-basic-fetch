import * as types from './products-types';

function fetchProductsRequest(){
    return {
        type: types.FETCH_PRODUCTS_REQUEST
    }
};
function fetchProductsSuccess(data) {
    return {
        type: types.FETCH_PRODUCTS_SUCCESS,
        payload: data,
    }
};
function fetchProductsError(error) {
    return {
        type: types.FETCH_PRODUCTS_ERROR,
        payload: error,
    }
}
function addProductRequest() {
    return {
        type: types.ADD_PRODUCT_REQUEST,
    }
 };
function addProductSuccess(product) {
    return {
        type: types.ADD_PRODUCT_SUCCESS,
        payload: product,
    }
}
function addProductError(error) {
    return {
        type: types.ADD_PRODUCT_ERROR,
        payload: error,
    }
}

const actionCreators = {
    fetchProductsRequest,
    fetchProductsSuccess,
    fetchProductsError,
    addProductRequest,
    addProductSuccess,
    addProductError
}
export default actionCreators;


/* import { createAction } from '@reduxjs/toolkit';

export const addProduct = createAction('products/add');
export const removeProduct = createAction('products/remove');
*/