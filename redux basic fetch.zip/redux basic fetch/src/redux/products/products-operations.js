import actions from './products-actions';
import * as API from '../../shared/service/API/products';


export const fetchProducts = () => {
    const func = async (dispatch) => {
        dispatch(actions.fetchProductsRequest());

        try {
            const data = await API.getProducts();
            dispatch(actions.fetchProductsSuccess(data)); 
        }
        catch (error) {
            dispatch(actions.fetchProductsError(error))
        }

    }
    return func;
}
export const addProduct = (product) => {
    const func = async (dispatch, getStore) => {
      
        const { products } = getStore();
        const isCopy = products.find(el => el.name === product.name);
        if (isCopy) {
            alert(`${product.name} is already in products`);
            return;
        }
        dispatch(actions.addProductRequest());
        try {
            const newProduct = await API.addProduct(product);
            dispatch(actions.addProductSuccess(newProduct));
        }
        catch (error) {
            dispatch(actions.addProductError(error));
        }
    }
    return func;
}