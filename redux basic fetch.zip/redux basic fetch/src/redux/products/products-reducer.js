import * as types from "./products-types";

const initialStore = {
    items: [],
    loading: false, 
    error: null,
}

const productsReducer = (productsStore = initialStore, action) => {
    const { type, payload } = action;
    switch (type) {
        case types.FETCH_PRODUCTS_REQUEST:
            return { ...productsStore, loading: true };
        case types.FETCH_PRODUCTS_SUCCESS:
            return { ...productsStore, loading: false, items: payload };
        case types.FETCH_PRODUCTS_ERROR:
            return { ...productsStore, error: payload };
        case types.ADD_PRODUCT_REQUEST:
            return { ...productsStore, loading: true };
        case types.ADD_PRODUCT_SUCCESS:
            return { ...productsStore, loading: false, items: [...productsStore.items, payload] };
        case types.ADD_PRODUCT_ERROR:
            return { ...productsStore, error: payload };
        default:
            return productsStore;
    }
}
export default productsReducer;






/* import { createReducer } from "@reduxjs/toolkit";
import { addProduct, removeProduct } from "./productsActions";

const productsReducer = createReducer([], {
    [addProduct]:(store, {payload}) => [...store, payload],
    [removeProduct]: (store, { payload }) =>  store.filter(({ id }) => id !== payload),
})

export default productsReducer; */

//push 
//splice