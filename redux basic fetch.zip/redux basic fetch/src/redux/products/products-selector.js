export const getLoading = ({products}) => products.loading; 
export const getError = ({products}) => products.error; 
export const getProducts = ({products}) => products.items;