/* import { createSlice } from "@reduxjs/toolkit";

const productSlice = createSlice({

    name: 'products',
    initialState: [],
    reducers: {
        add: (store, { payload }) => {
            const isProductInCart = store.find(el => el.id === payload.id);
            if (isProductInCart) {
                const newQuantity = isProductInCart.quantity + 1;
                isProductInCart.quantity = newQuantity;
            }
            else {
                store.push({...payload, quantity: 1});
            }
        },
        incrementQuantity: (store, { payload }) => {
            const product = store.find(el => el.id === payload);
            product.quantity += 1;
        } ,
        decrementQuantity: (store, { payload }) => {
            const product = store.find(el => el.id === payload);
            const productIndx = store.findIndex(el => el.id === payload);
            product.quantity -= 1;
            if (product.quantity < 0) {
                store.splice(productIndx, 1);
            }
        } ,
        remove:(store, { payload }) =>  store.filter(({ id }) => id !== payload),
    } 
})

export const { add, remove, incrementQuantity,decrementQuantity } = productSlice.actions;

export default productSlice.reducer; */