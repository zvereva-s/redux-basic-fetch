export const FETCH_PRODUCTS_REQUEST = 'products/fetch-request';
export const FETCH_PRODUCTS_SUCCESS = 'products/fetch-success';
export const FETCH_PRODUCTS_ERROR = 'products/fetch-error';

export const ADD_PRODUCT_REQUEST = 'product/add-request';
export const ADD_PRODUCT_SUCCESS = 'product/add-success';
export const ADD_PRODUCT_ERROR = 'product/add-error';



